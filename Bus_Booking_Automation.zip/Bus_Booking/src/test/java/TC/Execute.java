package TC;


import java.util.concurrent.TimeUnit;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Pages.Driver;
import Pages.ChooseBus;
import Pages.Home_page;
import Pages.Paasenger_details;
import Pages.Payment;



public class Execute extends Driver{


	@Test
	public void Execute() throws Exception{
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		//Home Page of application
		HP =new Home_page(driver);
		SoftAssert soft=new SoftAssert();
		HP.getorigin().click();
		Thread.sleep(2000);
		HP.getoriginvalue().click();
		Thread.sleep(2000);
		HP.getdestination().click();
		Thread.sleep(2000);
		HP.getdestinationvalue().click();
		Thread.sleep(2000);		
		HP.getcalendar().click();
		Thread.sleep(2000);
		HP.getnexticon().click();
		Thread.sleep(2000);
		HP.getdate().click();
		Thread.sleep(2000);
		HP.getsearch().click();
		Thread.sleep(2000);

		//Choose bus and seats
		CB =new ChooseBus();
		CB.Select();

		//Enter personal details
		PD=new Paasenger_details(driver);
		PD.NAME().sendKeys("UJWAL");
		Thread.sleep(2000);
		PD.PHONE().sendKeys("1234567890");
		Thread.sleep(2000);
		PD.MAIL().sendKeys("ujwal@gmail.com");
		Thread.sleep(2000);
		PD.Btn().click();
		Thread.sleep(20000);

		//Payment page
		PT=new Payment();
		PT.Pay();

	}

}




