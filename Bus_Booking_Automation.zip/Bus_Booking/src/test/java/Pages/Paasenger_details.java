package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paasenger_details extends Driver{

	@FindBy(xpath="//input[@class=\"payment_textName form-control pay-form-control\"]")
	WebElement Fullname;

	@FindBy(xpath="//input[@class='payment_txtPhoneLogin form-control pay-form-control']")
	WebElement PHNO;

	@FindBy(xpath="//input[@class='payment_txtEmail form-control pay-form-control']")
	WebElement Email;

	@FindBy(xpath="//a[@class='btn btn-orange']")
	WebElement NextBtn;



	public Paasenger_details(WebDriver driver){
		PageFactory.initElements(driver, this);
	}


	public WebElement NAME() {
		return Fullname;
	}

	public WebElement PHONE() {
		return PHNO;
	}

	public WebElement MAIL() {
		return Email;
	}

	public WebElement Btn() {
		return NextBtn;


	}

}
