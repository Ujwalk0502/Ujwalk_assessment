package Utilities;

import java.io.File;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Pages.Driver;

public class Screenshot extends Driver {

	public void getscreenshot() throws Exception{
		Date currentdate=new Date();
		String screenshotfile=currentdate.toString().replace("", "_").replace(":", "_");
		File screenshot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//"+screenshotfile+".png"));
	}
}
