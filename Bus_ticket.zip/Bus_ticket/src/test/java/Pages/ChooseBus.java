package Pages;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ChooseBus extends Driver{

	
	
	public void Select() throws Exception{
	List<Double> list=new ArrayList<Double>();
	String Expectednoofseats="6";
	
     for(int i=1;i<=8;i++){
	
	 WebElement Display = driver.findElement(By.xpath("(//div[contains(@class, 'busprice2')])[" + i + "]"));
	 String Pricevalue = Display.getText();
	 double val = Double.parseDouble(Pricevalue.replace(" RM ", "").trim());
	 list.add(val);

}
    
      Collections.sort(list);
      Double Cheapest = list.get(0);
      System.out.println("cheapest price is "+Cheapest+"");

      driver.findElement(By.xpath("(//div[@class='busprice2' and contains(.,'"+Cheapest+"')]|//a[.='Select'])[2]")).click();
       Thread.sleep(3000);
   
       //choose seats
     for(int j=1;j<7;j++){
	 driver.findElement(By.xpath("(//div[@class='seat_available'])["+j+"]")).click();
}
     String Noofseats = driver.findElement(By.xpath("//span[@class='seat_qty']")).getText();
     System.out.println(Noofseats + " seats selected");
   
     //click on proceed
     if(Expectednoofseats.equals(Noofseats)){
     
     driver.findElement(By.xpath("//input[@class='seatproceed']")).click();
     Thread.sleep(3000);
}		
     else{
 		System.out.println("Expected Number of seats not available");
 	}
 }
     }
	
	

