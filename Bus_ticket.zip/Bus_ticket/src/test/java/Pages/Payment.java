package Pages;


import org.openqa.selenium.By;
import org.testng.Assert;

public class Payment extends Driver {

	public void Pay() throws InterruptedException{
		String Expectedalert="Please select a payment method";
		
		
		driver.findElement(By.xpath("//input[@Name='payment_btnProceedPayment']")).click();
		Thread.sleep(2000);
		
		String Actualalert = driver.findElement(By.xpath("//div[@class='mt-4 text-semibold']")).getText();
		System.out.println(Actualalert);
		Assert.assertEquals(Actualalert, Expectedalert);
		driver.findElement(By.xpath("(//a[.='OK'])[2]")).click();
	}
}
