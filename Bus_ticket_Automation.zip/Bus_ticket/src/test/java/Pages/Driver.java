package Pages;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Driver {

	
	public static WebDriver driver;
	public static Home_page HP;
	public static ChooseBus CB;
	public static  Paasenger_details PD;
	public static  Payment PT;
	
	@Parameters({"Browser","URL"})
	@BeforeTest
	public void setup(String Browser, String URL) throws Exception{
		
		if (Browser.equalsIgnoreCase("chrome")){

			 System.setProperty("webdriver.chrome.driver","C:\\Users\\ukumar\\Selenium_workspace_2\\UJ_workspace\\chromedriver-win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			WebDriver driver = new ChromeDriver(options);
			 driver=new ChromeDriver();
		
	}
		else if(Browser.equalsIgnoreCase("firefox")){
			WebDriverManager.firefoxdriver().driverVersion("0.33.0").setup();
			/*FirefoxOptions options = new FirefoxOptions();
			options.addArguments("--headless");*/
			driver=new FirefoxDriver();
		}
		
		driver.get(URL);
		driver.manage().window().maximize();
		
		
		
	

	}
	
	@AfterTest
     public void end(){
		driver.quit();
	}
}