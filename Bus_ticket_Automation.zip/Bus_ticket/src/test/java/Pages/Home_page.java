package Pages;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Home_page extends Driver{

	@FindBy(xpath="//input[@id='txtOriginGeneral']")
	WebElement origin;
	
	@FindBy(xpath="(//div[@class='select2-result-label'])[2]")
	WebElement originvalue;
	
	@FindBy(xpath="//input[@id='txtDestinationGeneral']")
	WebElement destination;
	
	@FindBy(xpath="(//div[@class='select2-result-label'])[2]")
	WebElement destinationvalue;
	
	@FindBy(xpath="//input[@class='homedate form-control custom-form-control-search left txtDepartDateBooking hasDatepicker']")
    WebElement calendar;	
	
	@FindBy(xpath="//a[@title='Next']")
	WebElement widgetnext;
	
	@FindBy(xpath="//a[.='20']")
	WebElement date;
	
	@FindBy(xpath="//input[@id='btnBusSearchNewGeneral']")
	WebElement searchBtn;
	
	public Home_page(WebDriver driver){
	PageFactory.initElements(driver, this);
	}
	

	public WebElement getorigin() {
		return origin;
	}
	
	public WebElement getoriginvalue() {
		return originvalue;
	}

	public WebElement getdestination() {
		return destination;
	}
	
	public WebElement getdestinationvalue() {
		return destinationvalue;
		
		
	}

	public WebElement getcalendar() {
		return calendar;
	}
	
	public WebElement getnexticon() {
		return widgetnext;
	}
	
	public WebElement getdate() {
		return date;
	}
	
	public WebElement getsearch() {
		return searchBtn;
	}

}
